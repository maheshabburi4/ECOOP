// Generated from Ecoop.g4 by ANTLR 4.5
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link EcoopParser}.
 */
public interface EcoopListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link EcoopParser#cplusgrammar}.
	 * @param ctx the parse tree
	 */
	void enterCplusgrammar(EcoopParser.CplusgrammarContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#cplusgrammar}.
	 * @param ctx the parse tree
	 */
	void exitCplusgrammar(EcoopParser.CplusgrammarContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#translationUnit}.
	 * @param ctx the parse tree
	 */
	void enterTranslationUnit(EcoopParser.TranslationUnitContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#translationUnit}.
	 * @param ctx the parse tree
	 */
	void exitTranslationUnit(EcoopParser.TranslationUnitContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#externalDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterExternalDeclaration(EcoopParser.ExternalDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#externalDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitExternalDeclaration(EcoopParser.ExternalDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#functionDefinition}.
	 * @param ctx the parse tree
	 */
	void enterFunctionDefinition(EcoopParser.FunctionDefinitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#functionDefinition}.
	 * @param ctx the parse tree
	 */
	void exitFunctionDefinition(EcoopParser.FunctionDefinitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#declaration}.
	 * @param ctx the parse tree
	 */
	void enterDeclaration(EcoopParser.DeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#declaration}.
	 * @param ctx the parse tree
	 */
	void exitDeclaration(EcoopParser.DeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#declarationList}.
	 * @param ctx the parse tree
	 */
	void enterDeclarationList(EcoopParser.DeclarationListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#declarationList}.
	 * @param ctx the parse tree
	 */
	void exitDeclarationList(EcoopParser.DeclarationListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#declarationSpecifiers}.
	 * @param ctx the parse tree
	 */
	void enterDeclarationSpecifiers(EcoopParser.DeclarationSpecifiersContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#declarationSpecifiers}.
	 * @param ctx the parse tree
	 */
	void exitDeclarationSpecifiers(EcoopParser.DeclarationSpecifiersContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#declarationSpecifier}.
	 * @param ctx the parse tree
	 */
	void enterDeclarationSpecifier(EcoopParser.DeclarationSpecifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#declarationSpecifier}.
	 * @param ctx the parse tree
	 */
	void exitDeclarationSpecifier(EcoopParser.DeclarationSpecifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#structOrUnionSpecifier}.
	 * @param ctx the parse tree
	 */
	void enterStructOrUnionSpecifier(EcoopParser.StructOrUnionSpecifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#structOrUnionSpecifier}.
	 * @param ctx the parse tree
	 */
	void exitStructOrUnionSpecifier(EcoopParser.StructOrUnionSpecifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#structOrUnion}.
	 * @param ctx the parse tree
	 */
	void enterStructOrUnion(EcoopParser.StructOrUnionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#structOrUnion}.
	 * @param ctx the parse tree
	 */
	void exitStructOrUnion(EcoopParser.StructOrUnionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#structDeclarationList}.
	 * @param ctx the parse tree
	 */
	void enterStructDeclarationList(EcoopParser.StructDeclarationListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#structDeclarationList}.
	 * @param ctx the parse tree
	 */
	void exitStructDeclarationList(EcoopParser.StructDeclarationListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#typeSpecifier}.
	 * @param ctx the parse tree
	 */
	void enterTypeSpecifier(EcoopParser.TypeSpecifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#typeSpecifier}.
	 * @param ctx the parse tree
	 */
	void exitTypeSpecifier(EcoopParser.TypeSpecifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#initDeclaratorList}.
	 * @param ctx the parse tree
	 */
	void enterInitDeclaratorList(EcoopParser.InitDeclaratorListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#initDeclaratorList}.
	 * @param ctx the parse tree
	 */
	void exitInitDeclaratorList(EcoopParser.InitDeclaratorListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#initDeclarator}.
	 * @param ctx the parse tree
	 */
	void enterInitDeclarator(EcoopParser.InitDeclaratorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#initDeclarator}.
	 * @param ctx the parse tree
	 */
	void exitInitDeclarator(EcoopParser.InitDeclaratorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#structDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterStructDeclaration(EcoopParser.StructDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#structDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitStructDeclaration(EcoopParser.StructDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#specifierQualifierList}.
	 * @param ctx the parse tree
	 */
	void enterSpecifierQualifierList(EcoopParser.SpecifierQualifierListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#specifierQualifierList}.
	 * @param ctx the parse tree
	 */
	void exitSpecifierQualifierList(EcoopParser.SpecifierQualifierListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#structDeclaratorList}.
	 * @param ctx the parse tree
	 */
	void enterStructDeclaratorList(EcoopParser.StructDeclaratorListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#structDeclaratorList}.
	 * @param ctx the parse tree
	 */
	void exitStructDeclaratorList(EcoopParser.StructDeclaratorListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#structDeclarator}.
	 * @param ctx the parse tree
	 */
	void enterStructDeclarator(EcoopParser.StructDeclaratorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#structDeclarator}.
	 * @param ctx the parse tree
	 */
	void exitStructDeclarator(EcoopParser.StructDeclaratorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#enumeratorList}.
	 * @param ctx the parse tree
	 */
	void enterEnumeratorList(EcoopParser.EnumeratorListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#enumeratorList}.
	 * @param ctx the parse tree
	 */
	void exitEnumeratorList(EcoopParser.EnumeratorListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#enumerator}.
	 * @param ctx the parse tree
	 */
	void enterEnumerator(EcoopParser.EnumeratorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#enumerator}.
	 * @param ctx the parse tree
	 */
	void exitEnumerator(EcoopParser.EnumeratorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#enumerationConstant}.
	 * @param ctx the parse tree
	 */
	void enterEnumerationConstant(EcoopParser.EnumerationConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#enumerationConstant}.
	 * @param ctx the parse tree
	 */
	void exitEnumerationConstant(EcoopParser.EnumerationConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#declarator}.
	 * @param ctx the parse tree
	 */
	void enterDeclarator(EcoopParser.DeclaratorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#declarator}.
	 * @param ctx the parse tree
	 */
	void exitDeclarator(EcoopParser.DeclaratorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#directDeclarator}.
	 * @param ctx the parse tree
	 */
	void enterDirectDeclarator(EcoopParser.DirectDeclaratorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#directDeclarator}.
	 * @param ctx the parse tree
	 */
	void exitDirectDeclarator(EcoopParser.DirectDeclaratorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#pointer}.
	 * @param ctx the parse tree
	 */
	void enterPointer(EcoopParser.PointerContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#pointer}.
	 * @param ctx the parse tree
	 */
	void exitPointer(EcoopParser.PointerContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#parameterTypeList}.
	 * @param ctx the parse tree
	 */
	void enterParameterTypeList(EcoopParser.ParameterTypeListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#parameterTypeList}.
	 * @param ctx the parse tree
	 */
	void exitParameterTypeList(EcoopParser.ParameterTypeListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#parameterList}.
	 * @param ctx the parse tree
	 */
	void enterParameterList(EcoopParser.ParameterListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#parameterList}.
	 * @param ctx the parse tree
	 */
	void exitParameterList(EcoopParser.ParameterListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#parameterDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterParameterDeclaration(EcoopParser.ParameterDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#parameterDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitParameterDeclaration(EcoopParser.ParameterDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#identifierList}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierList(EcoopParser.IdentifierListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#identifierList}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierList(EcoopParser.IdentifierListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#typeName}.
	 * @param ctx the parse tree
	 */
	void enterTypeName(EcoopParser.TypeNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#typeName}.
	 * @param ctx the parse tree
	 */
	void exitTypeName(EcoopParser.TypeNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#initializer}.
	 * @param ctx the parse tree
	 */
	void enterInitializer(EcoopParser.InitializerContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#initializer}.
	 * @param ctx the parse tree
	 */
	void exitInitializer(EcoopParser.InitializerContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#initializerList}.
	 * @param ctx the parse tree
	 */
	void enterInitializerList(EcoopParser.InitializerListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#initializerList}.
	 * @param ctx the parse tree
	 */
	void exitInitializerList(EcoopParser.InitializerListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#abstractDeclarator}.
	 * @param ctx the parse tree
	 */
	void enterAbstractDeclarator(EcoopParser.AbstractDeclaratorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#abstractDeclarator}.
	 * @param ctx the parse tree
	 */
	void exitAbstractDeclarator(EcoopParser.AbstractDeclaratorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#directAbstractDeclarator}.
	 * @param ctx the parse tree
	 */
	void enterDirectAbstractDeclarator(EcoopParser.DirectAbstractDeclaratorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#directAbstractDeclarator}.
	 * @param ctx the parse tree
	 */
	void exitDirectAbstractDeclarator(EcoopParser.DirectAbstractDeclaratorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#typedefName}.
	 * @param ctx the parse tree
	 */
	void enterTypedefName(EcoopParser.TypedefNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#typedefName}.
	 * @param ctx the parse tree
	 */
	void exitTypedefName(EcoopParser.TypedefNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(EcoopParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(EcoopParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#expressionStatement}.
	 * @param ctx the parse tree
	 */
	void enterExpressionStatement(EcoopParser.ExpressionStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#expressionStatement}.
	 * @param ctx the parse tree
	 */
	void exitExpressionStatement(EcoopParser.ExpressionStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#selectionStatement}.
	 * @param ctx the parse tree
	 */
	void enterSelectionStatement(EcoopParser.SelectionStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#selectionStatement}.
	 * @param ctx the parse tree
	 */
	void exitSelectionStatement(EcoopParser.SelectionStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#iterationStatement}.
	 * @param ctx the parse tree
	 */
	void enterIterationStatement(EcoopParser.IterationStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#iterationStatement}.
	 * @param ctx the parse tree
	 */
	void exitIterationStatement(EcoopParser.IterationStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#jumpStatement}.
	 * @param ctx the parse tree
	 */
	void enterJumpStatement(EcoopParser.JumpStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#jumpStatement}.
	 * @param ctx the parse tree
	 */
	void exitJumpStatement(EcoopParser.JumpStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#compoundStatement}.
	 * @param ctx the parse tree
	 */
	void enterCompoundStatement(EcoopParser.CompoundStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#compoundStatement}.
	 * @param ctx the parse tree
	 */
	void exitCompoundStatement(EcoopParser.CompoundStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(EcoopParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(EcoopParser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#assignmentExpression}.
	 * @param ctx the parse tree
	 */
	void enterAssignmentExpression(EcoopParser.AssignmentExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#assignmentExpression}.
	 * @param ctx the parse tree
	 */
	void exitAssignmentExpression(EcoopParser.AssignmentExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#assignmentOperator}.
	 * @param ctx the parse tree
	 */
	void enterAssignmentOperator(EcoopParser.AssignmentOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#assignmentOperator}.
	 * @param ctx the parse tree
	 */
	void exitAssignmentOperator(EcoopParser.AssignmentOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#conditionalExpression}.
	 * @param ctx the parse tree
	 */
	void enterConditionalExpression(EcoopParser.ConditionalExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#conditionalExpression}.
	 * @param ctx the parse tree
	 */
	void exitConditionalExpression(EcoopParser.ConditionalExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#constantExpression}.
	 * @param ctx the parse tree
	 */
	void enterConstantExpression(EcoopParser.ConstantExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#constantExpression}.
	 * @param ctx the parse tree
	 */
	void exitConstantExpression(EcoopParser.ConstantExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#additiveExpression}.
	 * @param ctx the parse tree
	 */
	void enterAdditiveExpression(EcoopParser.AdditiveExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#additiveExpression}.
	 * @param ctx the parse tree
	 */
	void exitAdditiveExpression(EcoopParser.AdditiveExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void enterMultiplicativeExpression(EcoopParser.MultiplicativeExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void exitMultiplicativeExpression(EcoopParser.MultiplicativeExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#shiftExpression}.
	 * @param ctx the parse tree
	 */
	void enterShiftExpression(EcoopParser.ShiftExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#shiftExpression}.
	 * @param ctx the parse tree
	 */
	void exitShiftExpression(EcoopParser.ShiftExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#relationalExpression}.
	 * @param ctx the parse tree
	 */
	void enterRelationalExpression(EcoopParser.RelationalExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#relationalExpression}.
	 * @param ctx the parse tree
	 */
	void exitRelationalExpression(EcoopParser.RelationalExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#equalityExpression}.
	 * @param ctx the parse tree
	 */
	void enterEqualityExpression(EcoopParser.EqualityExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#equalityExpression}.
	 * @param ctx the parse tree
	 */
	void exitEqualityExpression(EcoopParser.EqualityExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#andExpression}.
	 * @param ctx the parse tree
	 */
	void enterAndExpression(EcoopParser.AndExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#andExpression}.
	 * @param ctx the parse tree
	 */
	void exitAndExpression(EcoopParser.AndExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#exclusiveOrExpression}.
	 * @param ctx the parse tree
	 */
	void enterExclusiveOrExpression(EcoopParser.ExclusiveOrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#exclusiveOrExpression}.
	 * @param ctx the parse tree
	 */
	void exitExclusiveOrExpression(EcoopParser.ExclusiveOrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#inclusiveOrExpression}.
	 * @param ctx the parse tree
	 */
	void enterInclusiveOrExpression(EcoopParser.InclusiveOrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#inclusiveOrExpression}.
	 * @param ctx the parse tree
	 */
	void exitInclusiveOrExpression(EcoopParser.InclusiveOrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void enterLogicalAndExpression(EcoopParser.LogicalAndExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void exitLogicalAndExpression(EcoopParser.LogicalAndExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void enterLogicalOrExpression(EcoopParser.LogicalOrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void exitLogicalOrExpression(EcoopParser.LogicalOrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#forExpression}.
	 * @param ctx the parse tree
	 */
	void enterForExpression(EcoopParser.ForExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#forExpression}.
	 * @param ctx the parse tree
	 */
	void exitForExpression(EcoopParser.ForExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExpression(EcoopParser.UnaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExpression(EcoopParser.UnaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#castExpression}.
	 * @param ctx the parse tree
	 */
	void enterCastExpression(EcoopParser.CastExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#castExpression}.
	 * @param ctx the parse tree
	 */
	void exitCastExpression(EcoopParser.CastExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#postfixExpression}.
	 * @param ctx the parse tree
	 */
	void enterPostfixExpression(EcoopParser.PostfixExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#postfixExpression}.
	 * @param ctx the parse tree
	 */
	void exitPostfixExpression(EcoopParser.PostfixExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#argumentExpressionList}.
	 * @param ctx the parse tree
	 */
	void enterArgumentExpressionList(EcoopParser.ArgumentExpressionListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#argumentExpressionList}.
	 * @param ctx the parse tree
	 */
	void exitArgumentExpressionList(EcoopParser.ArgumentExpressionListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#primaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterPrimaryExpression(EcoopParser.PrimaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#primaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitPrimaryExpression(EcoopParser.PrimaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#genericAssocList}.
	 * @param ctx the parse tree
	 */
	void enterGenericAssocList(EcoopParser.GenericAssocListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#genericAssocList}.
	 * @param ctx the parse tree
	 */
	void exitGenericAssocList(EcoopParser.GenericAssocListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#genericAssociation}.
	 * @param ctx the parse tree
	 */
	void enterGenericAssociation(EcoopParser.GenericAssociationContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#genericAssociation}.
	 * @param ctx the parse tree
	 */
	void exitGenericAssociation(EcoopParser.GenericAssociationContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#unaryOperator}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOperator(EcoopParser.UnaryOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#unaryOperator}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOperator(EcoopParser.UnaryOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#gccAttributeList}.
	 * @param ctx the parse tree
	 */
	void enterGccAttributeList(EcoopParser.GccAttributeListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#gccAttributeList}.
	 * @param ctx the parse tree
	 */
	void exitGccAttributeList(EcoopParser.GccAttributeListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#gccAttribute}.
	 * @param ctx the parse tree
	 */
	void enterGccAttribute(EcoopParser.GccAttributeContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#gccAttribute}.
	 * @param ctx the parse tree
	 */
	void exitGccAttribute(EcoopParser.GccAttributeContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#nestedParenthesesBlock}.
	 * @param ctx the parse tree
	 */
	void enterNestedParenthesesBlock(EcoopParser.NestedParenthesesBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#nestedParenthesesBlock}.
	 * @param ctx the parse tree
	 */
	void exitNestedParenthesesBlock(EcoopParser.NestedParenthesesBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#designation}.
	 * @param ctx the parse tree
	 */
	void enterDesignation(EcoopParser.DesignationContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#designation}.
	 * @param ctx the parse tree
	 */
	void exitDesignation(EcoopParser.DesignationContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#designatorList}.
	 * @param ctx the parse tree
	 */
	void enterDesignatorList(EcoopParser.DesignatorListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#designatorList}.
	 * @param ctx the parse tree
	 */
	void exitDesignatorList(EcoopParser.DesignatorListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#designator}.
	 * @param ctx the parse tree
	 */
	void enterDesignator(EcoopParser.DesignatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#designator}.
	 * @param ctx the parse tree
	 */
	void exitDesignator(EcoopParser.DesignatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#blockItemList}.
	 * @param ctx the parse tree
	 */
	void enterBlockItemList(EcoopParser.BlockItemListContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#blockItemList}.
	 * @param ctx the parse tree
	 */
	void exitBlockItemList(EcoopParser.BlockItemListContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#blockItem}.
	 * @param ctx the parse tree
	 */
	void enterBlockItem(EcoopParser.BlockItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#blockItem}.
	 * @param ctx the parse tree
	 */
	void exitBlockItem(EcoopParser.BlockItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#forCondition}.
	 * @param ctx the parse tree
	 */
	void enterForCondition(EcoopParser.ForConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#forCondition}.
	 * @param ctx the parse tree
	 */
	void exitForCondition(EcoopParser.ForConditionContext ctx);
	/**
	 * Enter a parse tree produced by {@link EcoopParser#forDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterForDeclaration(EcoopParser.ForDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link EcoopParser#forDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitForDeclaration(EcoopParser.ForDeclarationContext ctx);
}