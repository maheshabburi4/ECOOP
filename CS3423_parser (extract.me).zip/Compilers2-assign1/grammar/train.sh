#!/bin/bash
cd ./grammar
export CLASSPATH=".:/usr/local/lib/antlr-4.5-complete.jar:$CLASSPATH"
java -jar /usr/local/lib/antlr-4.5-complete.jar -o ../java/ecoop/ Ecoop.g4
java org.antlr.v4.Tool -o ../java/ecoop/ Ecoop.g4
echo "Completed Execution"