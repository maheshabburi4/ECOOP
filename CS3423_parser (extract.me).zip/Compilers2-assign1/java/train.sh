cd ./java
export CLASSPATH=".:/usr/local/lib/antlr-4.5-complete.jar:$CLASSPATH"
cd ./ecoop
javac *.java
read -p "Enter the name of testcase file: " name
java org.antlr.v4.runtime.misc.TestRig Ecoop cplusgrammar -gui < ../../testcases/$name